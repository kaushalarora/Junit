/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.calculator;

/**
 *
 * @author Junit_316
 */
public class Calculator {

    /**
     *
     * @param a
     * @param b
     * @return Add of a,b
     */
    public static int Add_316(int a, int b) {
        return a + b;
    }

    /**
     *
     * @param a
     * @param b
     * @return Multiply of a,b
     */
    public static int Multiply_316(int a, int b) {
        return a * b;
    }

    /**
     *
     * @param a
     * @param b
     * @return Division of a,b
     */
    public static long Division_316(int a, int b) {
        return a / b;
    }

    /**
     *
     * @param a
     * @param b
     * @return Subtract of a,b
     */
    public static int Subtract_316(int a, int b) {
        return a - b;
    }
}
